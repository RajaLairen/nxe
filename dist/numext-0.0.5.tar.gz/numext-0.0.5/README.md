# nxe
python module to extract numbers from string of characters containing numbers
